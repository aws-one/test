"""
Algoritmo Constructivo Problema Vehicle
Routing Problem with Time Windows – VRPTW
Feasibility and Lower boundages
Juan Fernando Riascos Goyes
"""

def is_feasible(route, visited_number, new_node, capacity, times):
    # Check capacity feasibility
    if new_node.number//1000 in visited_number and new_node.number//1000 != route[-1].number//1000:
        # print("因为访问过")
        return False
    total_demand = sum(node.demand for node in route) + new_node.demand

    if total_demand > capacity:# Use '>' to strictly enforce the capacity constraint
        # print("因为容量")
        return False

  
    current_time = 0
    current_low_temp = -99
    current_high_temp = 99
    for i in range(1, len(route)):
       
        current_time += times[route[i-1].index][route[i].index]

        if current_time < route[i].time_window[0]:
            current_time = route[i].time_window[0]
        
        if current_time > route[i].time_window[1]:
            # print("因为时间窗")
            return False

        if current_low_temp > route[i].high_temp or current_high_temp < route[i].low_temp:
            # print("因为时间窗")
            return False

        current_low_temp = max(current_low_temp, route[i].low_temp)
        current_high_temp = min(current_high_temp, route[i].high_temp)

        current_time += route[i].serv_time

    new_node_arrival_time = current_time + times[route[-1].index][new_node.index]


    
    if new_node_arrival_time < new_node.time_window[0]:
        new_node_arrival_time = new_node.time_window[0]
    if new_node_arrival_time > new_node.time_window[1]:
        # print("因为时间窗")
        return False  # Arrival too late for the new node

    if current_low_temp > new_node.high_temp or current_high_temp < new_node.low_temp:
        # print("因为温度")
        return False

    return True  




