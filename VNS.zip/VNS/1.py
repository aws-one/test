# import random
#
# def multi_point_swap(lst):
#     # 过滤掉 0 并获取元素个数
#     non_zero_elements = [i for i in lst if i != '0']
#     print("non_zero_elements", non_zero_elements)
#     num_non_zero = len(non_zero_elements)
#     # 计算需要交换的客户个数，取总个数的五分之一
#     num_swaps = num_non_zero // 3
#     print("num_swaps", num_swaps)
#     # 获取非零元素的索引
#     non_zero_indices = [i for i, x in enumerate(lst) if x != '0']
#     print("non_zero_indices", non_zero_indices)
#     # 随机选择需要交换的索引
#     swap_indices = random.sample(non_zero_indices, num_swaps)
#     print("swap_indices", swap_indices)
#     # 复制这些索引对应的元素
#     elements_to_swap = [lst[i] for i in swap_indices]
#     # 打乱这些元素
#     random.shuffle(elements_to_swap)
#     # 将打乱后的元素放回原列表
#     for i, index in enumerate(swap_indices):
#         lst[index] = elements_to_swap[i]
#     return lst
#
# # 原始列表
# original_list = [['0', '31002', '38001', '41002', '43001', '47001', '50001', '1001', '2001', '0', '21001', '27002', '28001', '29003', '30003', '22001', '24002', '0', '26001', '16001', '17001', '18001', '15001', '14001', '13001', '11001', '10001', '0', '8001', '7001', '9001', '9008'], ['0', '2002', '1002', '50002', '48002', '46003', '49003', '44001', '44003', '45001', '0', '43002', '38002', '38005', '39004', '35001', '40001', '36001', '37001', '0', '34001', '32001', '34003', '32002', '33001', '0', '20001', '28008', '29004', '29002', '28002', '29001', '30004', '30001', '0', '21002', '24001', '22002', '25001', '26002', '16002', '19001', '18002', '17002', '0', '10002', '12001', '14002', '13002', '8002', '7003', '6001', '5001', '0']]
#
# # 对每个子列表进行多点随机交换操作
# result_list = [multi_point_swap(sublist.copy()) for sublist in original_list]
# print("result_list", result_list)
# route = []
# for sublist in result_list:
#     route.append(sublist)
# print("route", route)


import os

# 定义输入和输出文件的路径
input_file = './processed_data/R112_200_processed.CSV'
temp_file = './processed_data/R112_200_processed_temp.CSV'

try:
    # 读取输入文件并修改数据
    with open(input_file, 'r') as infile, open(temp_file, 'w') as outfile:
        # 读取表头
        header = infile.readline().strip()
        outfile.write(header + '\n')

        # 读取第一行数据
        first_row = infile.readline().strip()
        if first_row:
            outfile.write(first_row + '\n')

        # 处理后续行数据
        for line in infile:
            row = line.strip().split()
            # 检查行的长度是否足够
            if len(row) >= 6:
                # 将第六列数据乘以 4
                row[5] = str(int(row[5]) * 4)
            new_line = ' '.join(row)
            outfile.write(new_line + '\n')

    # 用临时文件替换原文件
    os.replace(temp_file, input_file)
except FileNotFoundError:
    print(f"未找到文件: {input_file}")