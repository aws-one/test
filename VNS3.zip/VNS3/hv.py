# import numpy as np
#
# def HV_indicator(Population, optimum):
#     """
#     Hypervolume Indicator
#
#     :param Population: The population matrix (N x M).
#     :param optimum: The optimal reference point.
#     :return: Hypervolume score.
#     """
#     PopObj = Population
#     N, M = PopObj.shape
#     fmin = np.minimum(np.min(PopObj, axis=0), np.zeros(M))
#     fmax = np.max(optimum)
#     PopObj = (PopObj - fmin) / ((fmax - fmin) * 1.1)
#     PopObj = PopObj[np.all(PopObj <= 1, axis=1)]
#     RefPoint = np.ones(M)
#
#     if PopObj.shape[0] == 0:
#         return 0
#     elif M < 4:
#         # Calculate the exact HV value
#         PopObj_sorted = np.sort(PopObj, axis=0)
#         S = [(1, PopObj_sorted)]
#         for k in range(M - 1):
#             S_ = []
#             for i in range(len(S)):
#                 Stemp = Slice(S[i][1], k, RefPoint)
#                 for j in range(len(Stemp)):
#                     temp = (Stemp[j][0] * S[i][0], Stemp[j][1])
#                     S_ = Add(temp, S_)
#             S = S_
#         score = 0
#         for i in range(len(S)):
#             p = Head(S[i][1])
#             score += S[i][0] * np.abs(p[M - 1] - RefPoint[M - 1])
#         return score
#     else:
#         # Estimate the HV value by Monte Carlo estimation
#         SampleNum = int(1e6)
#         MaxValue = RefPoint
#         MinValue = np.min(PopObj, axis=0)
#         Samples = np.random.uniform(MinValue, MaxValue, (SampleNum, M))
#         for i in range(PopObj.shape[0]):
#             domi = np.ones(Samples.shape[0], dtype=bool)
#             m = 0
#             while m < M and np.any(domi):
#                 domi = domi & (PopObj[i, m] <= Samples[:, m])
#                 m += 1
#             Samples[domi, :] = []
#         return np.prod(MaxValue - MinValue) * (1 - len(Samples) / SampleNum)
#
# def Slice(pl, k, RefPoint):
#     p = Head(pl)
#     pl = Tail(pl)
#     ql = []
#     S = []
#     while len(pl) > 0:
#         ql = Insert(p, k + 1, ql)
#         p_ = Head(pl)
#         cell_ = [abs(p[k] - p_[k]), ql]
#         S = Add(cell_, S)
#         p = p_
#         pl = Tail(pl)
#     ql = Insert(p, k + 1, ql)
#     cell_ = [abs(p[k] - RefPoint[k]), ql]
#     S = Add(cell_, S)
#     return S
#
# def Insert(p, k, pl):
#     flag1 = 0
#     flag2 = 0
#     ql = []
#     while len(pl) > 0 and pl[0][k] < p[k]:
#         ql.append(pl[0])
#         pl = Tail(pl)
#     ql.append(p)
#     m = len(p)
#     while len(pl) > 0:
#         q = pl[0]
#         for i in range(k, m):
#             if p[i] < q[i]:
#                 flag1 = 1
#             elif p[i] > q[i]:
#                 flag2 = 1
#         if not (flag1 == 1 and flag2 == 0):
#             ql.append(pl[0])
#         pl = Tail(pl)
#     return ql
#
# def Head(pl):
#     return pl[0] if len(pl) > 0 else []
#
# def Tail(pl):
#     return pl[1:] if len(pl) > 1 else []
#
# def Add(cell_, S):
#     found = False
#     for k in range(len(S)):
#         if np.array_equal(cell_[1], S[k][1]):
#             S[k] = (S[k][0] + cell_[0], S[k][1])
#             found = True
#             break
#     if not found:
#         S.append(cell_)
#     return S
#
# import numpy as np
#
#
# def HV_indicator(Population, optimum):
#     """
#     Hypervolume Indicator
#
#     :param Population: The population matrix (N x M).
#     :param optimum: The optimal reference point.
#     :return: Hypervolume score.
#     """
#     PopObj = Population
#     N, M = PopObj.shape
#
#     # 归一化操作
#     fmin = np.minimum(np.min(PopObj, axis=0), np.zeros(M))
#     fmax = np.max(optimum)
#     PopObj = (PopObj - fmin) / ((fmax - fmin) * 1.1)
#     PopObj = PopObj[np.all(PopObj <= 1, axis=1)]  # 去除大于1的解
#     RefPoint = np.ones(M)
#
#     # 如果没有有效的解，则返回0
#     if PopObj.shape[0] == 0:
#         return 0
#     elif M < 4:
#         # 计算精确的超体积值
#         PopObj_sorted = np.sort(PopObj, axis=0)
#         S = [(1, PopObj_sorted)]
#
#         for k in range(M - 1):
#             S_ = []
#             for i in range(len(S)):
#                 Stemp = Slice(S[i][1], k, RefPoint)
#                 for j in range(len(Stemp)):
#                     temp = (Stemp[j][0] * S[i][0], Stemp[j][1])
#                     S_ = Add(temp, S_)
#             S = S_
#
#         score = 0
#         for i in range(len(S)):
#             p = Head(S[i][1])
#             score += S[i][0] * np.abs(p[M - 1] - RefPoint[M - 1])
#         return score
#     else:
#         # 使用蒙特卡罗估计超体积值
#         SampleNum = int(1e6)
#         MaxValue = RefPoint
#         MinValue = np.min(PopObj, axis=0)
#         Samples = np.random.uniform(MinValue, MaxValue, (SampleNum, M))
#
#         for i in range(PopObj.shape[0]):
#             domi = np.ones(Samples.shape[0], dtype=bool)
#             m = 0
#             while m < M and np.any(domi):
#                 domi = domi & (PopObj[i, m] <= Samples[:, m])
#                 m += 1
#             Samples[domi, :] = []
#
#         return np.prod(MaxValue - MinValue) * (1 - len(Samples) / SampleNum)
#
#
# def Slice(pl, k, RefPoint):
#     p = Head(pl)
#     pl = Tail(pl)
#     ql = []
#     S = []
#     while len(pl) > 0:
#         ql = Insert(p, k + 1, ql)
#         p_ = Head(pl)
#         cell_ = [abs(p[k] - p_[k]), ql]
#         S = Add(cell_, S)
#         p = p_
#         pl = Tail(pl)
#
#     ql = Insert(p, k + 1, ql)
#     cell_ = [abs(p[k] - RefPoint[k]), ql]
#     S = Add(cell_, S)
#     return S
#
#
# def Insert(p, k, pl):
#     ql = []
#     while len(pl) > 0 and pl[0][k] < p[k]:
#         ql.append(pl[0])
#         pl = Tail(pl)
#
#     ql.append(p)
#     m = len(p)
#     while len(pl) > 0:
#         q = pl[0]
#         flag1 = flag2 = 0
#         for i in range(k, m):
#             if p[i] < q[i]:
#                 flag1 = 1
#             elif p[i] > q[i]:
#                 flag2 = 1
#         if not (flag1 == 1 and flag2 == 0):
#             ql.append(pl[0])
#         pl = Tail(pl)
#
#     return ql
#
#
# def Head(pl):
#     return pl[0] if len(pl) > 0 else []
#
#
# def Tail(pl):
#     return pl[1:] if len(pl) > 1 else []
#
#
# def Add(cell_, S):
#     found = False
#     for k in range(len(S)):
#         if np.array_equal(cell_[1], S[k][1]):
#             S[k] = (S[k][0] + cell_[0], S[k][1])
#             found = True
#             break
#     if not found:
#         S.append(cell_)
#     return S
import numpy as np


def HV_indicator(Population, optimum):
    PopObj = Population
    PopObj = np.array(PopObj)
    N, M = PopObj.shape
    fmin = np.minimum(np.min(PopObj, axis=0), np.zeros(M))
    # print("fmin", fmin)
    fmax = np.maximum.reduceat(optimum, np.arange(len(optimum)))
    # print("fmax", fmax)
    PopObj = (PopObj - np.tile(fmin, (N, 1))) / np.tile((fmax - fmin) * 1.1, (N, 1))
    PopObj = PopObj[np.all(PopObj <= 1, axis=1)]
    RefPoint = np.ones(M)

    if PopObj.size == 0:
        score = 0
    elif M < 4:
        # Calculate the exact HV value
        pl = PopObj[np.lexsort(PopObj.T[::-1])]
        S = [(1, pl)]
        for k in range(M - 1):
            S_ = []
            for i in range(len(S)):
                Stemp = Slice(S[i][1], k, RefPoint)
                for j in range(len(Stemp)):
                    temp = (Stemp[j][0] * S[i][0], Stemp[j][1])
                    S_ = Add(temp, S_)
            S = S_
        score = 0
        for i in range(len(S)):
            p = Head(S[i][1])
            score += S[i][0] * abs(p[-1] - RefPoint[-1])
    else:
        # Estimate the HV value by Monte Carlo estimation
        SampleNum = 1000000
        MaxValue = RefPoint
        MinValue = np.min(PopObj, axis=0)
        np.random.seed(0)  # Set random seed for reproducibility
        Samples = np.random.uniform(np.tile(MinValue, (SampleNum, 1)), np.tile(MaxValue, (SampleNum, 1)))
        for i in range(PopObj.shape[0]):
            domi = np.all(PopObj[i] <= Samples, axis=1)
            Samples = Samples[~domi]
        score = np.prod(MaxValue - MinValue) * (1 - Samples.shape[0] / SampleNum)
    return score






def Slice(pl, k, RefPoint):
    p = Head(pl)
    pl = Tail(pl)
    ql = np.empty((0, pl.shape[1]))
    S = []
    while pl.size > 0:
        ql = Insert(p, k + 1, ql)
        p_ = Head(pl)
        cell_ = (abs(p[k] - p_[k]), ql)
        S = Add(cell_, S)
        p = p_
        pl = Tail(pl)
    ql = Insert(p, k + 1, ql)
    cell_ = (abs(p[k] - RefPoint[k]), ql)
    S = Add(cell_, S)
    return S


def Insert(p, k, pl):
    flag1 = 0
    flag2 = 0
    ql = np.empty((0, p.shape[0]))
    hp = Head(pl)
    while pl.size > 0 and hp[k] < p[k]:
        ql = np.vstack((ql, hp))
        pl = Tail(pl)
        hp = Head(pl)
    ql = np.vstack((ql, p))
    m = len(p)
    while pl.size > 0:
        q = Head(pl)
        for i in range(k, m):
            if p[i] < q[i]:
                flag1 = 1
            elif p[i] > q[i]:
                flag2 = 1
        if not (flag1 == 1 and flag2 == 0):
            ql = np.vstack((ql, Head(pl)))
        pl = Tail(pl)
    return ql


def Head(pl):
    if pl.size == 0:
        return np.array([])
    else:
        return pl[0]


def Tail(pl):
    if pl.shape[0] < 2:
        return np.empty((0, pl.shape[1]))
    else:
        return pl[1:]


def Add(cell_, S):
    n = len(S)
    m = 0
    for k in range(n):
        if np.array_equal(cell_[1], S[k][1]):
            S[k] = (S[k][0] + cell_[0], S[k][1])
            m = 1
            break
    if m == 0:
        S.append(cell_)
    return S

