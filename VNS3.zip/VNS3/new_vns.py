## Juan Fernando Riascos Goyes
## Constructive Heuristic Method for VRPTW problem

## Libraries
import os
import math
import numpy as np
# import matplotlib.pyplot as plt
from openpyxl import Workbook
import time
from Lecture import Nodo, save_to_excel, read_txt_file
from Feasibility_and_LB import is_feasible
import random
from hv import HV_indicator
import matplotlib.pyplot as plt
import ast
import pandas as pd
## Time of travel (Define by Euclidean Distance)
import copy


class PopIndividual:
    def __init__(self):
        self.position = None
        self.cost = None
        self.rank = None
        self.domination = []
        self.dominated = 0
        self.crowdingdistance = 0

    def __len__(self):
        # 假设 route 是一个列表，你可以根据 route 的实际数据结构修改这里的逻辑
        return len(self.position)

    def __repr__(self):
        return f"PopIndividual(position={self.position}), PopIndividual(cost={self.cost})"
def euclidean_distance(node1, node2):
    return math.sqrt((node1.x_cord - node2.x_cord) ** 2 + (node1.y_cord - node2.y_cord) ** 2)


## Function to calculate time travel (t_(i,j))
def calculate_travel_times(nodes):
    n = len(nodes)
    times = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            times[i][j] = euclidean_distance(nodes[i], nodes[j])
    return times


## Calculate the route distance for a route in
def calculate_route_distance(route, times):
    distance = 0.0
    for i in range(len(route) - 1):
        distance += times[route[i].index][route[i + 1].index]
    return distance


## Sum of the distances calculated above
def calculate_total_distance(routes, times):
    return sum(calculate_route_distance(route, times) for route in routes)

def calculate_route_loss_weight(route, times):
    close_time = 0.0
    open_time = 0.0
    loss_weight = 0.0
    arrive_time = 0.0
    wait_time = 0.0
    for i in range(len(route) - 1):
        arrive_time += (wait_time + times[route[i].index][route[i + 1].index] + route[i].serv_time)
        # print("route[i + 1].time_window[0]", route[i + 1].time_window[0])
        # print("")
        wait_time = max(0,(route[i + 1].time_window[0] - arrive_time))
        # print("wait_time", wait_time)
        close_time += (times[route[i].index][route[i + 1].index] + wait_time)
        open_time += route[i + 1].serv_time
        # print("close_time", close_time)
        # print("open_time", open_time)
        loss_weight += route[i + 1].demand * (1 - math.exp(-(0.001 * close_time + 0.003 * open_time)))

    return loss_weight

def calculate_total_loss_weight(routes, times):
    return sum(calculate_route_loss_weight(route, times) for route in routes)

def calculate_total_vehicles(routes):
    # print("len(routes)", len(routes))
    return len(routes)


def calculate_route_cost(route, times):
    f1 = calculate_total_vehicles(route)
    f2 = calculate_total_loss_weight(route, times)
    f3 = calculate_total_distance(route, times)
    return [f1, f2, f3]


def route_selection1(nodes, capacity, times):
    depot = nodes[0]
    customers = nodes[1:]
    routes = []
    while customers:
        route = [depot]
        visited_number = []
        current_load = 0
        while True:  # 每次完成一辆车
            feasible_customers = [cust for cust in customers if is_feasible(route, visited_number, cust, capacity, times)]
            if not feasible_customers:
                break
            # 随机选择一个可行客户
            next_customer = random.choice(feasible_customers)
            if current_load + next_customer.demand <= capacity:
                route.append(next_customer)
                visited_number.append(next_customer.number//1000)
                current_load += next_customer.demand
                customers.remove(next_customer)
            else:
                break
        route.append(depot)
        routes.append(route)

    return routes

def route_selection(nodes, DRL, capacity, times):
    # print("DRL", DRL)
    # print("nodes", len(nodes))
    # 提取仓库节点
    depot = nodes[0]
    # 用于存储所有未分配到合适路线的客户
    all_customers = []
    # 用于存储最终的所有路线
    population = []
    # 提取除仓库外的所有客户节点
    original_customers = nodes[1:]
    # print("original_customers", original_customers)

    # 复制一份原始客户列表，避免在操作过程中影响原始列表
    customers = original_customers.copy()
    # print("customers", customers)
    # customers = copy.deepcopy(original_customers)
    # print("customers", customers)
    # 遍历 DRL 列表中的每个顺序
    for index, order in enumerate(DRL):
        # print("-----------------------------------------------------------------------------------")
        # print("order", order)
        k = 0
        for i in order:
            if i != '0':
                k += 1
        # print("len(order)", k)
        routes = []
        i = 1
        route = [depot]
        visited_number = []
        current_load = 0
        while True:
            if i >= len(order):
                break
            next_customer_str = order[i]
            if next_customer_str != "0":
                next_customer = next((cust for cust in original_customers if str(cust.number) == next_customer_str), None)
                # print("next_customer", next_customer)
                if next_customer is not None:
                    route2 = copy.deepcopy(route)
                    if is_feasible(route2, visited_number, next_customer, capacity, times):
                        route.append(next_customer)
                        # print("route", route)
                        visited_number.append(next_customer.number//1000)
                        current_load += next_customer.demand
                        customers.remove(next_customer)
                        # print("len(customers)", len(customers))
                    else:
                        customers.remove(next_customer)
                        # print("len(customers)", len(customers))
                        all_customers.append(next_customer)
                        # print("len(all_customers)", len(all_customers))
                i += 1
            else:
                route.append(depot)
                # print("len(route)", len(route)-2)
                routes.append(route)
                # print("routes", routes)
                route = [depot]
                visited_number = []
                i += 1
        # print("customers", len(customers))
        # print("routes", routes)
        population.extend(routes)

    # print("customers", customers)



    # print("all_customers", all_customers)
    new_routes = []
    while all_customers:
        new_route = [depot]
        visited_number = []
        current_load = 0
        while True:   # 每次完成一辆车
            new_route2 = copy.deepcopy(new_route)
            feasible_customers = [cust for cust in all_customers if is_feasible(new_route2, visited_number, cust, capacity, times)]
            #print("feasible_customers",feasible_customers)
            if not feasible_customers:
                break
            next_customer = random.choice(feasible_customers)
            # print("next_customer", next_customer)
            if current_load + next_customer.demand <= capacity:
                new_route.append(next_customer)
                visited_number.append(next_customer.number//1000)
                current_load += next_customer.demand
                all_customers.remove(next_customer)
                # print("all_customers", all_customers)
            else:
                break
        new_route.append(depot)
        # print("new_route", new_route)
        new_routes.append(new_route)
        # print("new_routes", new_routes)
    population.extend(new_routes)
    # print("population", population)
    return population

# def route_selection(nodes, group_customers_list_all_files, DRL, capacity, times):
#     print("DRL", DRL)
#     print("nodes", len(nodes))
#     depot = nodes[0]
#     all_customers = []
#     population = []
#     for index, sub_group in enumerate(group_customers_list_all_files):
#         # print("index", index)
#         # print("sub_group", sub_group)
#         original_customers = []
#         # print("sub_group", sub_group)
#         for route_list in sub_group:
#             # print("route_list", route_list)
#             for cust in route_list:
#                 original_customers.append(cust)
#
#         order = DRL[index]
#         # print("order", order)
#         # print("original_customers", len(original_customers))
#         customers = original_customers.copy()  # 每次循环都复制一份原始客户列表
#         routes = []
#         i = 1
#         while customers:
#             # print("TRUE")
#             route = [depot]
#             current_load = 0
#             while True:   # 每次完成一辆车
#                 if not customers:
#                     # 如果 i 超出 order 列表范围或者 customers 列表为空，跳出内层循环
#                     break
#                 next_customer = order[i]
#                 # print("next_customer")
#                 if next_customer != "0":
#                     # print("next_customer", next_customer)
#
#                     for customer in original_customers:
#                         # print("customer.number", customer.number)
#                         if str(customer.number) == next_customer:
#                             next_customer = customer
#                             break
#                             # print("next_customer1", next_customer)
#                     if is_feasible(route, next_customer, capacity, times):
#                         route.append(next_customer)
#                         # print("route", route)
#                         current_load += next_customer.demand
#                         customers.remove(next_customer)
#                         # print("customers", customers)
#                         i += 1
#                     else:
#                         customers.remove(next_customer)
#                         # print("customers", customers)
#                         all_customers.append(next_customer)
#                         # print("all_customers", all_customers)
#                         i += 1
#
#                 else:
#                     route.append(depot)
#                     # print("route", route)
#                     routes.append(route)
#                     i += 1
#                     break
#         route.append(depot)
#         routes.append(route)
#         # print("routes", routes)
#         population.extend(routes)
#
#
#     # print("all_customers", all_customers)
#     while all_customers:
#         new_route = [depot]
#         new_routes = []
#         current_load = 0
#         while True:   # 每次完成一辆车
#             feasible_customers = [cust for cust in all_customers if is_feasible(new_route, cust, capacity, times)]
#             #print("feasible_customers",feasible_customers)
#             if not feasible_customers:
#                 break
#             next_customer = random.choice(feasible_customers)
#             # print("next_customer", next_customer)
#             if current_load + next_customer.demand <= capacity:
#                 new_route.append(next_customer)
#                 current_load += next_customer.demand
#                 all_customers.remove(next_customer)
#                 # print("all_customers", all_customers)
#             else:
#                 break
#         new_route.append(depot)
#         new_routes.append(new_route)
#         # print("routes", routes)
#         population.extend(new_routes)
#
#
#     print("population", population)
#     return population
def is_route_feasible(route, capacity, times):
    """
    Verifica si una ruta completa es factible utilizando la función is_feasible.
    """
    # Iniciamos con una ruta vacía que contiene solo el depósito
    feasible_route = [route[0]]  # Suponiendo que el depósito es el primer nodo
    visited_number = []
    for node in route[1:]:
        if is_feasible(feasible_route, visited_number, node, capacity, times):
            feasible_route.append(node)
            visited_number.append(node.number//1000)
        else:
            return False  # La ruta no es factible al agregar este nodo
    return True


def swap_between_routes(routes, times, capacity):   # 交换不在同一条路径中的两个顾客
    import random
    # print("routes", routes)
    new_routes = PopIndividual()  # 创建一个 PopIndividual 实例
    new_routes.position = [route.copy() for route in routes.position]
    # new_routes = [route.copy() for route in routes.position]
    # print("new_routes", new_routes)
    if len(new_routes.position) < 2:
        return new_routes  # No hay suficientes rutas para intercambiar

    route_indices = list(range(len(new_routes)))
    # print("route_indices", route_indices)
    random.shuffle(route_indices)

    for i in route_indices:
        for j in route_indices:
            if i >= j:
                continue  # Evitar duplicados y misma ruta

            route1 = new_routes.position[i]
            route2 = new_routes.position[j]

            # Excluir los depósitos
            customers1 = route1[1:-1]
            customers2 = route2[1:-1]

            for idx1, cust1 in enumerate(customers1):
                for idx2, cust2 in enumerate(customers2):
                    # Crear copias de las rutas
                    temp_route1 = route1.copy()
                    temp_route2 = route2.copy()

                    # Intercambiar los clientes
                    temp_route1[idx1 + 1] = cust2  # +1 por el depósito al inicio
                    temp_route2[idx2 + 1] = cust1

                    # Verificar factibilidad de ambas rutas utilizando is_feasible
                    if (is_route_feasible(temp_route1, capacity, times) and
                            is_route_feasible(temp_route2, capacity, times)):
                        # Reemplazar las rutas originales
                        new_routes.position[i] = temp_route1
                        new_routes.position[j] = temp_route2
                        # print("new_routes", new_routes)
                        return new_routes  # Retornar después de la primera mejora
    # print("new_routes", new_routes)
    return new_routes  # Si no se encontraron mejoras

def relocate_between_routes(routes, times, capacity):   # 把一条路径中的一个顾客放到另一条路径中
    import random
    # new_routes = [route.copy() for route in routes]
    new_routes = PopIndividual()  # 创建一个 PopIndividual 实例
    new_routes.position = [route.copy() for route in routes.position]
    if len(new_routes) < 2:
        return new_routes  # No hay suficientes rutas para reubicar

    route_indices = list(range(len(new_routes)))
    random.shuffle(route_indices)

    for i in route_indices:
        for j in route_indices:
            if i == j:
                continue  # No reubicar en la misma ruta

            route_from = new_routes.position[i]
            route_to = new_routes.position[j]

            # Excluir los depósitos
            customers_from = route_from[1:-1]

            for idx_cust, cust in enumerate(customers_from):
                # Crear copias de las rutas
                temp_route_from = route_from.copy()
                temp_route_to = route_to.copy()

                # Remover el cliente de la ruta origen
                del temp_route_from[idx_cust + 1]  # +1 por el depósito al inicio

                # Intentar insertar el cliente en todas las posiciones de la ruta destino
                for k in range(1, len(temp_route_to)):  # Evitar posición 0 (depósito)
                    temp_route_to_insert = temp_route_to[:k] + [cust] + temp_route_to[k:]

                    # Verificar factibilidad de ambas rutas utilizando is_feasible
                    if (is_route_feasible(temp_route_from, capacity, times) and
                            is_route_feasible(temp_route_to_insert, capacity, times)):
                        # Reemplazar las rutas originales
                        new_routes.position[i] = temp_route_from
                        new_routes.position[j] = temp_route_to_insert
                        return new_routes  # Retornar después de la primera mejora
    return new_routes  # Si no se encontraron mejoras

def two_opt_within_route(routes, times, capacity):
    # new_routes = [route.copy() for route in routes]
    new_routes = PopIndividual()  # 创建一个 PopIndividual 实例
    new_routes.position = [route.copy() for route in routes.position]
    for idx, route in enumerate(new_routes.position):
        best_distance = calculate_route_distance(route, times)
        best_route = route.copy()
        improved = False

        for i in range(1, len(route) - 2):
            for j in range(i + 1, len(route) - 1):
                new_route = route[:i] + route[i:j + 1][::-1] + route[j + 1:]

                # Verificar factibilidad utilizando is_feasible
                if is_route_feasible(new_route, capacity, times):
                    new_distance = calculate_route_distance(new_route, times)
                    if new_distance + 1e-6 < best_distance:
                        best_distance = new_distance
                        best_route = new_route
                        improved = True

        if improved:
            new_routes.position[idx] = best_route
            return new_routes  # Retornar después de la primera mejora

    return new_routes  # Si no se encontraron mejoras


def calcrowdingdistance(pop, F):
    nf = len(F)
    for i in range(nf):
        # 收集当前前沿面个体的目标函数值
        costs = np.array([pop[index].cost for index in F[i]])
        nobj, n = costs.shape
        # print("nobj", nobj)
        # print("n", n)
        d = np.zeros((nobj, n))
        for j in range(n):
            # 对第 j 个目标的函数值进行排序
            cj = np.sort(costs[:, j])
            # print("cj", cj)
            so = np.argsort(costs[:, j])
            # print("so", so)
            # 边界点的拥挤距离设为无穷大
            d[so[0], j] = np.inf
            # d[so[-1], j] = np.inf
            # print("d1", d)
            for k in range(1, nobj - 1):
                # 分母为 0 时进行处理，避免除零错误
                denominator = abs(cj[0] - cj[-1])
                if denominator == 0:
                    denominator = 1e-10
                d[so[k], j] = abs(cj[k + 1] - cj[k - 1]) / denominator
                # print("d2", d)
            d[so[-1], j] = np.inf
        for m in range(nobj):
            # 计算每个个体的拥挤距离
            pop[F[i][m]].crowdingdistance = np.sum(d[m, :])
            #print("")
    return pop
def Sortpop(pop):

    def get_crowdingdistance(item):
        return item.crowdingdistance
    def get_rank(item):
        return item.rank
    # 按照 crowdingdistance 降序排列
    pop.sort(key=get_crowdingdistance, reverse=True)
    # 按照 rank 升序排列
    pop.sort(key=get_rank)
    # print("pop", pop)
    return pop
def dominate(p, q):
    # print("p", p)
    # print("q", q)
    p_cost = p.cost
    # print("p_cost", p_cost)
    q_cost = q.cost
    # print("q_cost", q_cost)
    less_than = all([p_val <= q_val for p_val, q_val in zip(p_cost, q_cost)])
    strictly_less_than = any([p_val < q_val for p_val, q_val in zip(p_cost, q_cost)])
    return less_than and strictly_less_than
def nondominatedsort(pop):
    npop = len(pop)
    # 初始化支配集和被支配个数
    pop = [copy.deepcopy(ind) for ind in pop]
    for i in range(npop):
        # 支配解集
        pop[i].domination = []
        # 被支配次数
        pop[i].dominated = 0
    F = [[]]
    for i in range(npop):
        p = pop[i]
        for j in range(i + 1, npop):
            q = pop[j]
            if dominate(p, q):
                p.domination.append(j)
                q.dominated += 1
            elif dominate(q, p):
                q.domination.append(i)
                p.dominated += 1
        if pop[i].dominated == 0:
            pop[i].rank = 1
            F[0].append(i)
    k = 1
    while True:
        Q = []
        for i in F[k - 1]:
            p = pop[i]
            for j in p.domination:
                q = pop[j]
                q.dominated -= 1
                if q.dominated == 0:
                    Q.append(j)
                    q.rank = k + 1
        if not Q:
            break
        else:
            F.append(Q)
            k += 1
    return pop, F    # 返回[[0, 3], [2], [1]]


def vns_local_search(routes, times, capacity, iteration):
    best_sol = routes


    # S1~S6 每个局部搜索算子的最大执行次数，这里平均分配
    Max_N = 3 + 3 * math.floor(math.sqrt(iteration))
    # print("Max_N", Max_N)
    S = [Max_N // 3 for _ in range(3)]
    # print("S", S)
    # s1~s6 记录每个局部搜索算子已执行的次数
    s = [0 for _ in range(3)]
    l = 1
    # print("s", s)

    while sum(s) < Max_N:

        # print("sum(s)", sum(s))
        if s[l - 1] < S[l - 1]:
            # print("T")
            s[l - 1] += 1
            # print("s", s)
            # 这里需要根据实际算子逻辑实现不同的局部搜索操作，以下为示例占位
            if l == 1:
                new_sol = swap_between_routes(routes, times, capacity)
            elif l == 2:
                new_sol = relocate_between_routes(routes, times, capacity)
            elif l == 3:
                new_sol = two_opt_within_route(routes, times, capacity)


            new_sol.cost = calculate_route_cost(new_sol.position, times)


            if dominate(new_sol, best_sol):
                best_sol = new_sol


                l = 1
        else:
            l = (l + 1) % 3 + 1
            # print("l", l)
    # print("Best Solution", best_sol)
    return best_sol



def combined_search2(population, times, run, capacity, group_customers_list_all_files, start_time, run_file_name):
    IGD_values = []
    hv_values = []
    iteration = 0
    iteration_numbers = []  # 用于记录迭代次数

    result_folder = "hv_results5"
    # 如果文件夹不存在，则创建它

    if not os.path.exists(result_folder):
        os.makedirs(result_folder)

    run_str = str(run)

    # 动态生成文件名
    output_file_name = os.path.join(result_folder, run_file_name, run_str)
    output_file_name1 = os.path.join(output_file_name, f"{run_file_name}_hv_values.csv")
    output_file_name2 = os.path.join(output_file_name, f"{run_file_name}_IGD.csv")

    os.makedirs(os.path.dirname(output_file_name1), exist_ok=True)
    os.makedirs(os.path.dirname(output_file_name2), exist_ok=True)


    end_time = start_time + 800

    destroy_operators = [(remove_similar_customers, 0.2), (neighborhood_structure2, 0.2), (distance_worst_removal, 0.2),
                         (weight_worst_removal, 0.2), (random_removal, 0.2)]

    # # 初始化修复算子及其权重
    insertion_strategies = [(insert_customers, 0.25), (insert_customers_weight, 0.25),
                            (insert_customers_distance, 0.25), (q_regret_insertion, 0.25)]



    while time.time() < end_time:
        print("time", time.time() - start_time)
        # if iteration % 2 == 0 and iteration > 0:
        #     improvement_threshold = improvement_threshold * (0.995 ** (iteration))
        pop2 = copy.deepcopy(population)


        new_population = lns_search(population, times, capacity, group_customers_list_all_files, destroy_operators, insertion_strategies)
        # print("new_population", new_population)
        combined_population = pop2 + new_population
        for individual in combined_population:
            individual.cost = calculate_route_cost(individual.position, times)
            # print("individual.cost", individual.cost)


        # print("cost", cost)
        pop, F = nondominatedsort(combined_population)
        # for individual in pop:
        #     print("individual.cost", individual.cost)
        #     print("individual.rank", individual.rank)
        # print("F1",F)
        for index, sol in enumerate(pop):
            improved_sol = vns_local_search(sol, times, capacity, iteration)
            original_index = pop.index(sol)
            pop[original_index] = improved_sol


        pop, F = nondominatedsort(pop)
        # for individual in pop:
        #     print("individual.cost1", individual.cost)
        #     print("individual.rank1", individual.rank)
        pop = calcrowdingdistance(pop, F)
        # for individual in pop:
        #     print("individual.cost2", individual.cost)
        #     print("individual.crowdingdistance2", individual.crowdingdistance)
        pop = Sortpop(pop)
        # for individual in pop:
        #     print("individual.cost3", individual.cost)
        #     print("individual.rank3", individual.rank)
        #     print("individual3.crowdingdistance3", individual.crowdingdistance)
        population = pop[0:30]
        # for individual in population:
        #     print("individual.cost4", individual.cost)
        #     print("individual.rank4", individual.rank)



        indices = [i for i, val in enumerate(F[0])]
        # 从 pop 中选取相应的元素
        F1 = [pop[i] for i in indices]
        # 提取 F1 中的 cost 元素

        costs = [item.cost for item in F1]
        print("costs", costs)
        # lujin = [item.position for item in F1]
        # print("lujin", lujin)


        ref = np.array([150, 5000, 20000])  # 假设 ref 是一个标量，根据实际情况修改
        hv = HV_indicator(costs, ref)

        referencePoints = load_reference_points(run_file_name)
        IGD = IGD_indicator(costs, referencePoints)
        print(f"Generation {iteration}: HV value = {hv}")
        print(f"Generation {iteration}: IGD value = {IGD}")

        iteration_numbers.append(iteration + 1)
        iteration += 1

        IGD_values.append(IGD)
        try:
            # 以追加模式打开文件写入数据
            with open(output_file_name2, 'a') as file:
                file.write(f'{iteration},{IGD}\n')
        except Exception as e:
            print(f"向文件 {output_file_name2} 写入数据时出现错误: {e}")
            break

        hv_values.append(hv)
        try:
            # 以追加模式打开文件写入数据
            with open(output_file_name1, 'a') as file:
                file.write(f'{iteration},{hv}\n')
        except Exception as e:
            print(f"向文件 {output_file_name1} 写入数据时出现错误: {e}")
            break

        if iteration % 50 == 0:
            plt.plot(iteration_numbers, hv_values)
            plt.xlabel('Iteration')
            plt.ylabel('HV Value')
            plt.title('HV Value over Iterations')
            plt.grid(True)
            plt.show()
            plt.clf()

        if iteration % 50 == 0:
            plt.plot(iteration_numbers, IGD_values)
            plt.xlabel('Iteration')
            plt.ylabel('IGD Value')
            plt.title('IGD Value over Iterations')
            plt.grid(True)
            plt.show()
            plt.clf()

    last_generation_cost = costs
    last_generation_hv = hv
    last_generation_IGD = IGD

    cost_output_file_name = os.path.join(output_file_name, f"{run_file_name}_last_generation_cost.csv")
    try:
        with open(cost_output_file_name, 'w') as file:
            # 写入表头
            file.write('Objective1,Objective2,Objective3\n')  # 根据实际目标数量修改表头
            for cost_vector in last_generation_cost:
                # 将 cost 向量的元素用逗号连接并写入文件
                cost_str = ','.join(map(str, cost_vector))
                file.write(f'{cost_str}\n')
    except Exception as e:
        print(f"创建文件 {cost_output_file_name} 或写入数据时出现错误: {e}")

        # 保存HV收敛图
    plt.figure()
    plt.plot(iteration_numbers, hv_values)
    plt.xlabel('Iteration')
    plt.ylabel('HV Value')
    plt.title('HV Value Convergence')
    plt.grid(True)
    hv_fig_path = os.path.join(output_file_name, f"{run_file_name}_hv_convergence.png")
    plt.savefig(hv_fig_path)
    plt.close()

    # 保存IGD收敛图
    plt.figure()
    plt.plot(iteration_numbers, IGD_values)
    plt.xlabel('Iteration')
    plt.ylabel('IGD Value')
    plt.title('IGD Value Convergence')
    plt.grid(True)
    igd_fig_path = os.path.join(output_file_name, f"{run_file_name}_igd_convergence.png")
    plt.savefig(igd_fig_path)
    plt.close()

    print(f"HV收敛图已保存至: {hv_fig_path}")
    print(f"IGD收敛图已保存至: {igd_fig_path}")

    return last_generation_hv, last_generation_IGD


def load_reference_points(dataset: str) -> np.ndarray:
    """
    从文件加载参考点（假设文件名为 {dataset}_PF.txt）
    :param dataset: 数据集名称（如 C101）
    :return: 参考点矩阵 [R, M]
    """
    ref_path = os.path.join('reference_results', f"{dataset}_PF.txt")
    if not os.path.exists(ref_path):
        print(f"参考点文件 {ref_path} 不存在！")
        return np.empty((0, 3))

    reference_points = []
    with open(ref_path, 'r') as f:
        for line in f:
            ref_point = list(map(float, line.strip().split(',')))
            reference_points.append(ref_point)
    return np.array(reference_points)


def IGD_indicator(F2, referencePoints):
    """
    计算 Inverted Generational Distance Plus (IGD+)
    F2: 当前算法的目标值矩阵 [N, M]
    referencePoints: 参考点集合 [R, M]
    """
    # 防止除零错误
    min_values = np.min(referencePoints, axis=0)
    max_values = np.max(referencePoints, axis=0)
    range_values = max_values - min_values
    range_values[range_values < np.finfo(float).eps] = 1.0  # 若某目标值完全相同，范围设为1

    # 归一化参考点
    norm_ref_points = (referencePoints - min_values) / range_values

    # 归一化F2
    norm_F2 = (F2 - min_values) / range_values

    # 初始化累积距离
    total_distance = 0.0

    # 遍历每个参考点
    for i in range(norm_ref_points.shape[0]):
        ref_point = norm_ref_points[i, :]

        # 计算参考点到F2每个点的改进距离
        # 对每个目标，若解优于参考点，则差值设为0
        diff = norm_F2 - ref_point
        diff[diff < 0] = 0  # 关键改进：忽略优于参考点的维度

        # 计算欧几里得距离
        distances = np.sqrt(np.sum(diff ** 2, axis=1))

        # 找到最近的距离
        min_distance = np.min(distances)

        # 累加最近距离
        total_distance += min_distance

    # 计算平均距离(IGD+)
    IGD_plus = total_distance / norm_ref_points.shape[0]
    return IGD_plus



def read_groups_from_file(file_path):
    groups = []
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('Group') and ':' in line:
                group_data = line.split(':')[1].strip()
                try:
                    group_list = eval(group_data)
                    groups.append(group_list)
                except Exception as e:
                    print(f"解析 {line} 时出错: {e}")
    return groups



def write_results_to_file(results, output_file_path):
    with open(output_file_path, 'w') as file:
        for i, group_customers in enumerate(results, 1):
            file.write(f"Group{i} 客户: {group_customers}\n")

def find_shortest_routes(routes):
    min_len = float('inf')
    shortest_routes_indices = []
    for i, route in enumerate(routes.position):
        route_len = len(route) - 2  # 减去起点和终点的仓库
        if route_len < min_len:
            min_len = route_len
            shortest_routes_indices = [i]
        elif route_len == min_len:
            shortest_routes_indices.append(i)
    return shortest_routes_indices



def lns_search(population, times, capacity, group_customers_list_all_files, destroy_operators, insertion_strategies):
    # print("destroy_operators", destroy_operators)
    # print("insertion_strategies", insertion_strategies)
    operator_performance_destroy = [0] * len(destroy_operators)
    operator_performance_insertion = [0] * len(insertion_strategies)


    learning_rate = 0.1
    new_population = []


    for sol in population:
        # 随机选择破坏算子
        destroy_operator_index = random.choices(range(len(destroy_operators)), weights=[w for _, w in destroy_operators])[0]
        destroy_operator = destroy_operators[destroy_operator_index][0]
        # print("destroy_operator_index", destroy_operator_index)
        # 执行破坏操作，得到新的路线和移除的客户
        new_route, removed_customers = destroy_operator(sol, times, capacity, group_customers_list_all_files)
        # print("removed_customers", removed_customers)
        # print("new_route", new_route)
        # 随机选择修复算子

        insertion_strategy_index = random.choices(range(len(insertion_strategies)), weights=[w for _, w in insertion_strategies])[0]
        insertion_strategy = insertion_strategies[insertion_strategy_index][0]


        # print("insertion_strategy", insertion_strategy)
        new_sol = insertion_strategy(removed_customers, new_route, capacity, times, sol)
        # print("new_sol2", new_sol)
        new_sol.cost = calculate_route_cost(new_sol.position, times)
        sol.cost = calculate_route_cost(sol.position, times)
        # sol_tost = total_cost(sol.position, times)
        # new_sol_tost = total_cost(new_sol.position, times)
        # 简单示例：假设新解比原解好则认为该算子表现好
        # print("new_sol.cost[0]", new_sol.cost[0])
        # print("sol.cost[0]", sol.cost[0])
        if new_sol is not None and dominate(new_sol, sol):
        # if new_sol is not None and new_sol.cost[0] < sol.cost[0]:
            operator_performance_destroy[destroy_operator_index] += 1
            if insertion_strategy_index != None:
                operator_performance_insertion[insertion_strategy_index] += 1

        # 将新解添加到新种群中
        new_population.append(new_sol)
    # print("operator_performance_destroy", operator_performance_destroy)
    # print("operator_performance_insertion", operator_performance_insertion)

    # 动态调整破坏算子权重
    total_performance_destroy = sum(operator_performance_destroy)
    if total_performance_destroy > 0:
        for i in range(len(destroy_operators)):
            new_weight = destroy_operators[i][1] + learning_rate * (
                    operator_performance_destroy[i] / total_performance_destroy - destroy_operators[i][1])
            destroy_operators[i] = (destroy_operators[i][0], new_weight)

    # 动态调整修复算子权重
    total_performance_insertion = sum(operator_performance_insertion)
    if total_performance_insertion > 0:
        for i in range(len(insertion_strategies)):
            new_weight = insertion_strategies[i][1] + learning_rate * (
                    operator_performance_insertion[i] / total_performance_insertion - insertion_strategies[i][1])
            insertion_strategies[i] = (insertion_strategies[i][0], new_weight)

    return new_population



def neighborhood_structure1(routes, times, capacity, group_customers_list_all_files):
    # 初始化最少客户数和对应的路线索引
    min_customers = float('inf')
    selected_index = None

    # 遍历所有路线，找到客户数最少的路线
    for i, route in enumerate(routes.position):
        # 计算路线中的客户数，排除起点和终点的仓库
        num_customers = len(route[1:-1])
        if num_customers < min_customers:
            min_customers = num_customers
            selected_index = i

    # 移除客户数最少的路线中的客户
    removed_customers = routes.position[selected_index][1:-1]

    # 创建新的个体
    new_routes = PopIndividual()
    # 构建新的路线列表，排除客户数最少的路线
    new_routes.position = routes.position[:selected_index] + routes.position[selected_index + 1:]

    return new_routes, removed_customers



def neighborhood_structure2(routes, times, capacity, group_customers_list_all_files):
    # 随机选择一条路线索引
    selected_index = random.randint(0, len(routes.position) - 1)

    # 移除选中路线中的客户
    removed_customers = routes.position[selected_index][1:-1]

    # 创建新的个体
    new_routes = PopIndividual()
    # 构建新的路线列表，排除选中的路线
    new_routes.position = routes.position[:selected_index] + routes.position[selected_index + 1:]

    return new_routes, removed_customers


def remove_similar_customers(routes, times, capacity, group_customers_list_all_files):
    # 把所有客户组展平成一个一维列表
    flattened_group_customers = [group for sublist in group_customers_list_all_files for group in sublist]

    new_routes = PopIndividual()
    new_routes.position = [route.copy() for route in routes.position]

    # 若有客户组可供选择
    if flattened_group_customers:
        # 随机选择一个客户组的索引
        selected_index = random.randint(0, len(flattened_group_customers) - 1)
        # 获取选中的客户组
        selected_group = flattened_group_customers[selected_index]
    else:
        # 若没有客户组，选中的客户组为空
        selected_group = []

    # 移除所选组的客户
    new_routes_list = []
    for route in new_routes.position:
        # 过滤掉路径中属于所选客户组的客户
        new_route = [customer for customer in route if customer not in selected_group]
        # 若路径长度大于 2（假设路径至少包含起点和终点），则保留该路径
        if len(new_route) > 2:
            new_routes_list.append(new_route)
    # 更新新的路径列表
    new_routes.position = new_routes_list

    return new_routes, selected_group
def create_new_route(route, removed_customers):
    new_route = PopIndividual()
    new_route.position = []
    for sub_route in route.position:
        new_sub_route = [sub_route[0]]
        for customer in sub_route[1:len(sub_route) - 1]:
            if customer not in removed_customers:
                new_sub_route.append(customer)
        new_sub_route.append(sub_route[-1])
        if len(new_sub_route) > 2:  # 检查子路线长度
            new_route.position.append(new_sub_route)
    return new_route

def distance_worst_removal(route, times, capacity, group_customers_list_all_files):
    num_remove = 20
    # print("route", route)
    cost_before_removal = calculate_total_distance(route.position, times)

    all_customers = []
    for sub_route in route.position:
        all_customers.extend(sub_route[1:len(sub_route) - 1])
    # print("all_customers", all_customers)
    removal_options = []
    for i, customer in enumerate(all_customers):
        new_route = create_new_route(route, [customer])
        cost_after_removal = calculate_total_distance(new_route.position, times)
        cost_decrement = cost_before_removal - cost_after_removal
        removal_options.append((i, cost_decrement))
    # print("removal_options", removal_options)
    removal_options.sort(key=lambda x: x[1], reverse=True)
    # print("removal_options", removal_options)
    selected_indices = [option[0] for option in removal_options[:num_remove]]
    removed_customers = [all_customers[i] for i in selected_indices]

    new_route = create_new_route(route, removed_customers)
    # ("new_route", new_route)
    # print("removed_customers", removed_customers)
    return new_route, removed_customers
def weight_worst_removal(route, times, capacity, group_customers_list_all_files):
    num_remove = 20
    # print("route", route)
    cost_before_removal = calculate_total_loss_weight(route.position, times)

    all_customers = []
    for sub_route in route.position:
        all_customers.extend(sub_route[1:len(sub_route) - 1])
    # print("all_customers", all_customers)
    removal_options = []
    for i, customer in enumerate(all_customers):
        new_route = create_new_route(route, [customer])
        cost_after_removal = calculate_total_loss_weight(new_route.position, times)
        cost_decrement = cost_before_removal - cost_after_removal
        removal_options.append((i, cost_decrement))
    # print("removal_options", removal_options)
    removal_options.sort(key=lambda x: x[1], reverse=True)
    # print("removal_options", removal_options)
    selected_indices = [option[0] for option in removal_options[:num_remove]]
    removed_customers = [all_customers[i] for i in selected_indices]

    new_route = create_new_route(route, removed_customers)

    return new_route, removed_customers


def new_route_selection(nodes, capacity, times):
    depot = nodes[0]
    customers = nodes[1:]
    routes = []
    while customers:
        route = [depot]
        visited_number = []
        current_load = 0
        while True:  # 每次完成一辆车
            feasible_customers = [cust for cust in customers if is_feasible(route, visited_number, cust, capacity, times)]
            if not feasible_customers:
                break
            # 随机选择一个可行客户
            next_customer = random.choice(feasible_customers)
            if current_load + next_customer.demand <= capacity:
                route.append(next_customer)
                visited_number.append(current_load + next_customer.demand)
                current_load += next_customer.demand
                customers.remove(next_customer)
            else:
                break
        route.append(depot)
        routes.append(route)

    return routes
def random_removal(routes,  times, capacity, group_customers_list_all_files):
    # print("routes", routes)
    num_remove = 20
    all_customers = [customer for sub_route in routes.position for customer in sub_route[1:len(sub_route)-1]]
    # print("all_customers", all_customers)
    # 确保 num_remove 不大于可抽取的元素数量
    num_remove = min(num_remove, len(all_customers))
    # 从 all_customers 中随机抽取 num_remove 个不重复的索引
    indices = random.sample(range(len(all_customers)), num_remove)
    # 根据抽取的索引，找到要移除的客户
    removed_customers = [all_customers[i] for i in indices]
    # print("removed_customers", removed_customers)
    # 生成新的客户列表，排除被移除的客户
    new_all_customers = [customer for i, customer in enumerate(all_customers) if i not in indices]
    new_route = PopIndividual()  # 创建一个 PopIndividual 实例
    new_route.position = []

    for sub_route in routes.position:
        new_sub_route = [sub_route[0]]
        for customer in sub_route:
            if customer!=sub_route[0] :
                if customer in new_all_customers:
                    new_sub_route.append(customer)
        new_sub_route.append(sub_route[0])
        if len(new_sub_route) > 2:
            new_route.position.append(new_sub_route)
    # print("new_route", new_route)
    # print("removed_customers", removed_customers)
    return new_route, removed_customers


def insert_customers(removed_customers, routes, capacity, times, sol):
    # print("routes", routes)
    # print("capacity", capacity)
    # print("remove", removed_customers)
    # print("sol", sol)
    for customer in removed_customers:
        inserted = False
        for index, route in enumerate(routes.position):
            # print("routes", routes)
            for i in range(1, len(route)):
                temp_route = route.copy()
                temp_route.insert(i, customer)
                if is_route_feasible(temp_route, capacity, times):
                    routes.position[index] = temp_route
                    # print("route", routes[index])
                    inserted = True
                    break
            if inserted:
                break
        if not inserted:
            # print("插入失败")
            # start_customer = routes.position[0][0]
            # end_customer = routes.position[0][0]
            # new_sub_route = [start_customer, customer, end_customer]
            # if is_route_feasible(new_sub_route, capacity, times):
            #     routes.position.append(new_sub_route)
            # print(" ----------------")
            # print("sol2", sol)
            return sol
    # print("routes", routes)
    return routes


def insert_customers_time(removed_customers, routes, capacity, times, sol):
    # print("removed_customers", removed_customers)
    # print("routes", routes)
    sorted_customers = sorted(removed_customers, key=lambda c: c.time_window[0])
    start_customer = routes.position[0][0]
    end_customer = routes.position[0][0]

    while sorted_customers:
        new_sub_route = [start_customer]
        remaining_customers = []

        for customer in sorted_customers:
            temp_route = new_sub_route + [customer] + [end_customer]
            if is_route_feasible(temp_route, capacity, times):
                new_sub_route.append(customer)
            else:
                remaining_customers.append(customer)

        new_sub_route.append(end_customer)
        if len(new_sub_route) > 2:
            routes.position.append(new_sub_route)

        sorted_customers = remaining_customers
    # print("routes", routes)
    return routes




def total_cost(route, times):
    f1 = calculate_total_vehicles(route)
    f2 = calculate_total_loss_weight(route, times)
    f3 = calculate_total_distance(route, times)
    return 100 * f1 + 4 * f2 + f3



def q_regret_insertion(remove_set, routes, capacity, times, sol):
    # print("routes", routes)
    # print("capacity", capacity)
    # print("remove", remove_set)
    # print("sol", sol)
    # q-后悔值插入
    q=5


    for customer in remove_set:
        insertion_costs = []
        valid_indices = []  # 用于存储合法插入位置的索引
        original_total_cost = total_cost(routes.position, times)
        for i, route in enumerate(routes.position):
            for j in range(1, len(route)):
                # 生成插入客户后的新路线
                new_route = route[:j] + [customer] + route[j:]

                # 检查新路线是否合法
                if is_route_feasible(new_route, capacity, times):
                    new_routes = PopIndividual()
                    new_routes.position = [route.copy() for route in routes.position]
                    new_routes.position[i] = new_route
                    # 调用成本函数计算插入操作的成本
                    new_total_cost = total_cost(new_routes.position, times)
                    cost = new_total_cost - original_total_cost
                    # 将计算得到的成本添加到插入成本列表中
                    insertion_costs.append(cost)
                    # 记录合法插入位置的索引
                    valid_indices.append((i, j))

        if insertion_costs:
            # 对插入成本列表进行排序
            sorted_costs = sorted(enumerate(insertion_costs), key=lambda x: x[1])
            # 计算 q - 后悔值
            regret_value = sum([cost for _, cost in sorted_costs[:q]])
            # 找到最小成本的索引
            best_cost_index = sorted_costs[0][0]
            # 获取最佳插入路线和位置
            best_route, best_position = valid_indices[best_cost_index]
            # 将客户插入到最佳路线的最佳位置
            routes.position[best_route].insert(best_position, customer)


        else:
            # start_customer = routes.position[0][0]
            # end_customer = routes.position[0][0]
            # new_sub_route = [start_customer, customer, end_customer]
            # if is_route_feasible(new_sub_route, capacity, times):
            #     routes.position.append(new_sub_route)
            # print("--------------")
            # print("sol", sol)
            return sol

    # print("routes", routes)
    return routes




def insert_customers_distance(removed_customers, routes, capacity, times, sol):

    for customer in removed_customers:
        inserted = False
        min_increase = float('inf')
        best_route_index = None
        best_insert_index = None

        # 遍历所有路线
        route_list = routes.position.copy()
        for route_index, route in enumerate(routes.position):

            for insert_index in range(1, len(route)):
                temp_route = route.copy()
                temp_route.insert(insert_index, customer)

                # 检查插入后的路线是否可行
                # print("temp_route", temp_route)
                if is_route_feasible(temp_route, capacity, times):
                    # 计算插入前和插入后的总距离
                    route_list[route_index] = temp_route
                    original_distance = calculate_total_distance(routes.position, times)
                    new_distance = calculate_total_distance(route_list, times)
                    distance_increase = new_distance - original_distance

                    # 如果距离增加量更小，则更新最优插入位置
                    if distance_increase < min_increase:
                        min_increase = distance_increase
                        best_route_index = route_index
                        best_insert_index = insert_index

        # 如果找到了可行的插入位置，则进行插入
        if best_route_index is not None and best_insert_index is not None:
            routes.position[best_route_index].insert(best_insert_index, customer)
            inserted = True
        if not inserted:
            # start_customer = routes.position[0][0]
            # end_customer = routes.position[0][0]
            # new_sub_route = [start_customer, customer, end_customer]
            # if is_route_feasible(new_sub_route, capacity, times):
            #     routes.position.append(new_sub_route)
            return sol
    return routes


def insert_customers_weight(removed_customers, routes, capacity, times, sol):

    for customer in removed_customers:
        inserted = False
        min_increase = float('inf')
        best_route_index = None
        best_insert_index = None

        # 遍历所有路线
        route_list = routes.position.copy()
        for route_index, route in enumerate(routes.position):
            # 遍历路线中的每个插入位置
            # print("route", route)
            for insert_index in range(1, len(route)):
                temp_route = route.copy()
                temp_route.insert(insert_index, customer)

                # 检查插入后的路线是否可行
                if is_route_feasible(temp_route, capacity, times):
                    # 计算插入前和插入后的总距离
                    route_list[route_index] = temp_route
                    original_distance = calculate_total_loss_weight(routes.position, times)
                    new_distance = calculate_total_loss_weight(route_list, times)
                    distance_increase = new_distance - original_distance

                    # 如果距离增加量更小，则更新最优插入位置
                    if distance_increase < min_increase:
                        min_increase = distance_increase
                        best_route_index = route_index
                        best_insert_index = insert_index

        # 如果找到了可行的插入位置，则进行插入
        if best_route_index is not None and best_insert_index is not None:
            routes.position[best_route_index].insert(best_insert_index, customer)
            inserted = True
        if not inserted:
            # start_customer = routes.position[0][0]
            # end_customer = routes.position[0][0]
            # new_sub_route = [start_customer, customer, end_customer]
            # if is_route_feasible(new_sub_route, capacity, times):
            #     routes.position.append(new_sub_route)
            return sol

    return routes



def extract_customers(group, nodes):
    return [node for node in nodes if node.number in group]

# 读取文件中的分组信息
def read_groups_from_file(file_path):
    groups = []
    with open(file_path, 'r') as file:
        lines = file.readlines()[1:]  # 跳过第一行 "Group: group1"

        # 处理每一行
        for line in lines:
            if line.startswith("Cluster"):
                # 提取Cluster编号和节点列表
                cluster_info = line.strip().split(": ")
                cluster_index = int(cluster_info[0].split()[1])  # 获取 Cluster 编号
                nodes = list(map(int, cluster_info[1].strip("[]").split(", ")))  # 提取节点列表
                groups.append(nodes)
    return groups

# 读取所有文件并处理
def process_all_files(input_dir, nodes):
    group_customers_list_all_files = []

    # 遍历k_meas_result文件夹中的所有txt文件
    for file_name in os.listdir(input_dir):
        if file_name.endswith('.txt'):
            file_path = os.path.join(input_dir, file_name)
            # print(f"Processing file: {file_name}")

            # 读取并提取每个文件中的分组信息
            groups = read_groups_from_file(file_path)
            # print("Groups:", groups)

            # 对每个分组调用 extract_customers 获取对应节点
            group_customers_list = []
            for group in groups:
                group_customers = extract_customers(group, nodes)
                group_customers_list.append(group_customers)

            group_customers_list_all_files.append(group_customers_list)

    return group_customers_list_all_files




# def vrptw_solver():   用来跑参考点
#     datasets = ['R106', 'R107', 'R108', 'R109', 'R110']
#
#     num_runs = 5  # 每份数据运行的次数
#     for user_input in datasets:
#         for run in range(1, num_runs + 1):
#             print(f"\n处理数据: {user_input}, 第 {run}/{num_runs} 次运行")
#
#             # 构建处理后数据文件的文件名和路径
#             filename = f"{user_input}_processed.txt"
#             file_path = os.path.join("processed_data", filename)
#
#
#             # 检查文件是否存在
#             if os.path.exists(file_path):
#                 # 读取文件获取相关信息
#                 n, Q, nodes = read_txt_file(file_path)
#                 print("n", n)
#                 print("Q", Q)
#
#                 # 构建 k_meas_result 目录下的文件路径
#                 input_dir = os.path.join('k_meas_result', f"{user_input}.txt")
#
#
#                 # 处理所有文件并获取结果
#                 group_customers_list_all_files = process_all_files(input_dir, nodes)
#                 # print("group_customers_list_all_files", group_customers_list_all_files)
#
#
#                 times = calculate_travel_times(nodes)  # 每两个节点之间的距离矩阵，也是用时矩阵
#                 # print("times", times)
#
#
#
#                 m = 20
#
#                 pop = [PopIndividual() for _ in range(m)]
#
#                 results_file_path = os.path.join('results100', user_input, 'all_merged_routes.txt')
#                 with open(results_file_path, 'r') as file:
#                     drl_list_str = file.readline()
#                     drl_list = ast.literal_eval(drl_list_str)
#                 # print("drl_list", drl_list)
#                 for i in range(0, m):
#                     # result_list = [multi_point_swap(sublist.copy(), nodes) for sublist in original_list]
#                     # print("result_list", result_list)
#                     # print("drl_list[i]", drl_list[i])
#                     routes = route_selection(nodes, drl_list[i], Q, times)
#                     pop[i].position = routes
#                 print("pop", pop)
#                 start_time = time.time()
#                 hv = combined_search(pop, times, run, Q, group_customers_list_all_files, start_time, user_input, drl_list, nodes)
#                 print("hv", hv)
#                 computation_time = time.time() - start_time
#                 # total_time = time.time() - total_computation_time
#                 print("computation_time", computation_time)
#                 # print("total_time", total_time)
#             else:
#                 print(f"Archivo {filename} no encontrado.")



# def vrptw_solver():       # 用来跑主实验
#     datasets = ['C103', 'C104', 'C105', 'C106', 'C107', 'C108', 'C109',
#                 'C201', 'C202', 'C203', 'C204', 'C205', 'C206', 'C207', 'C208',
#                 'R101', 'R102', 'R103', 'R104', 'R105', 'R106', 'R107', 'R108', 'R109', 'R110']
#
#     num_runs = 3
#
#     excel_file_name1 = 'HV_Values.xlsx'
#     excel_file_name2 = 'IGD_Values.xlsx'
#
#     # 定义表头
#     hv_header = ['数据集'] + [f'HV({i})' for i in range(1, num_runs + 1)]
#     igd_header = ['数据集'] + [f'IGD({i})' for i in range(1, num_runs + 1)]
#
#     # 初始化 Excel 文件，确保表头正确
#     def init_excel(file_path, header):
#         if not os.path.exists(file_path):
#             pd.DataFrame(columns=header).to_excel(file_path, index=False)
#             print(f"创建 {file_path} 并写入表头")
#         else:
#             existing_df = pd.read_excel(file_path)
#             if list(existing_df.columns) != header:
#                 pd.DataFrame(columns=header).to_excel(file_path, index=False)
#                 print(f"修复 {file_path} 表头")
#
#     init_excel(excel_file_name1, hv_header)
#     init_excel(excel_file_name2, igd_header)
#     # 每份数据运行的次数
#     for user_input in datasets:
#         hv_list = []
#         IGD_list = []
#         for run in range(1, num_runs + 1):
#             print(f"\n处理数据: {user_input}, 第 {run}/{num_runs} 次运行")
#
#             # 构建处理后数据文件的文件名和路径
#             filename = f"{user_input}_processed.txt"
#             file_path = os.path.join("processed_data", filename)
#
#
#             # 检查文件是否存在
#             if os.path.exists(file_path):
#                 # 读取文件获取相关信息
#                 n, Q, nodes = read_txt_file(file_path)
#                 print("n", n)
#                 print("Q", Q)
#
#                 # 构建 k_meas_result 目录下的文件路径
#                 input_dir = os.path.join('k_meas_result', f"{user_input}.txt")
#
#
#                 # 处理所有文件并获取结果
#                 group_customers_list_all_files = process_all_files(input_dir, nodes)
#                 # print("group_customers_list_all_files", group_customers_list_all_files)
#
#
#                 times = calculate_travel_times(nodes)  # 每两个节点之间的距离矩阵，也是用时矩阵
#                 # print("times", times)
#
#
#
#                 m = 20
#
#                 pop = [PopIndividual() for _ in range(m)]
#
#                 results_file_path = os.path.join('results2', user_input, 'all_merged_routes.txt')
#                 with open(results_file_path, 'r') as file:
#                     drl_list_str = file.readline()
#                     drl_list = ast.literal_eval(drl_list_str)
#                 # print("drl_list", drl_list)
#                 for i in range(0, m):
#                     # result_list = [multi_point_swap(sublist.copy(), nodes) for sublist in original_list]
#                     # print("result_list", result_list)
#                     # print("drl_list[i]", drl_list[i])
#                     routes = route_selection(nodes, drl_list[i], Q, times)
#                     pop[i].position = routes
#                 print("pop", pop)
#                 start_time = time.time()
#                 last_generation_hv, last_generation_IGD = combined_search2(pop, times, run, Q, group_customers_list_all_files, start_time, user_input, drl_list, nodes)
#
#                 hv_list.append(last_generation_hv)
#                 IGD_list.append(last_generation_IGD)
#
#
#                 computation_time = time.time() - start_time
#                 # total_time = time.time() - total_computation_time
#                 print("computation_time", computation_time)
#                 # print("total_time", total_time)
#             else:
#                 print(f"Archivo {filename} no encontrado.")
#
#                 # 写入 HV 数据到 Excel
#         try:
#             # 构造新数据行，字典形式保证列对齐
#             new_hv_data = {
#                 '数据集': user_input
#             }
#             for i in range(1, num_runs + 1):
#                 new_hv_data[f'HV({i})'] = hv_list[i - 1]
#
#             # 读取已有数据
#             hv_df = pd.read_excel(excel_file_name1)
#             # 追加新行
#             hv_df = pd.concat([hv_df, pd.DataFrame([new_hv_data])], ignore_index=True)
#             # 写入，保留表头
#             hv_df.to_excel(excel_file_name1, index=False)
#             print(f'成功写入 {user_input} 的 HV 值到 {excel_file_name1}')
#         except Exception as e:
#             print(f'写入 {user_input} 的 HV 值失败: {str(e)}')
#
#         # 写入 IGD 数据到 Excel
#         try:
#             new_igd_data = {
#                 '数据集': user_input
#             }
#             for i in range(1, num_runs + 1):
#                 new_igd_data[f'IGD({i})'] = IGD_list[i - 1]
#
#             igd_df = pd.read_excel(excel_file_name2)
#             igd_df = pd.concat([igd_df, pd.DataFrame([new_igd_data])], ignore_index=True)
#             igd_df.to_excel(excel_file_name2, index=False)
#             print(f'成功写入 {user_input} 的 IGD 值到 {excel_file_name2}')
#         except Exception as e:
#             print(f'写入 {user_input} 的 IGD 值失败: {str(e)}')
#
# vrptw_solver()



# def vrptw_solver1():    跑dDRL的PF面
#     # 创建总文件夹
#     output_folder = 'all_datasets_costs'
#     os.makedirs(output_folder, exist_ok=True)
#
#     datasets = ['C101', 'C102', 'C103', 'C104', 'C105', 'C106', 'C107', 'C108', 'C109',
#                 'C201', 'C202', 'C203', 'C204', 'C205', 'C206', 'C207', 'C208',
#                 'R101', 'R102', 'R103', 'R104', 'R105', 'R106', 'R107', 'R108', 'R109', 'R110']
#
#     for user_input in datasets:
#         filename = f"{user_input}_processed.txt"
#         file_path = os.path.join("processed_data", filename)
#
#         # 检查文件是否存在
#         if not os.path.exists(file_path):
#             print(f"文件不存在: {file_path}")
#             continue
#
#         # 读取文件获取相关信息
#         n, Q, nodes = read_txt_file(file_path)
#         times = calculate_travel_times(nodes)
#
#         m = 20
#         pop = [PopIndividual() for _ in range(m)]
#
#         results_file_path = os.path.join('results3', user_input, 'all_merged_routes.txt')
#         if not os.path.exists(results_file_path):
#             print(f"结果文件不存在: {results_file_path}")
#             continue
#
#         with open(results_file_path, 'r') as file:
#             drl_list_str = file.readline()
#             drl_list = ast.literal_eval(drl_list_str)
#
#         # 创建或打开对应的结果文件（按需求格式，这里用csv模拟类似文本格式的列展示）
#         result_file_path = os.path.join(output_folder, f"{user_input}_objectives.txt")
#         # 先清空已存在文件内容（如果是追加模式会重复，根据需求选择，这里重新生成）
#         with open(result_file_path, 'w') as f:
#             f.write("Objective1,Objective2,Objective3\n")
#
#         with open(result_file_path, 'a') as res_file:
#             # 计算并写入每个个体的目标函数值
#             for i in range(m):
#                 routes = route_selection(nodes, drl_list[i], Q, times)
#                 pop[i].position = routes
#                 # 假设 calculate_route_cost 现在返回的是包含三个目标值的列表或元组，如 [obj1, obj2, obj3]
#                 objectives = calculate_route_cost(pop[i].position, times)
#                 res_file.write(f"{objectives[0]},{objectives[1]},{objectives[2]}\n")
#
#         print(f"已完成 {user_input}，目标函数值数据已保存至 {result_file_path}")
#
#
# vrptw_solver1()


def vrptw_solver():       # 用来跑消融实验
    datasets = ['C101', 'C102', 'C103', 'C104', 'C105', 'C106', 'C107', 'C108', 'C109',
                'C201', 'C202', 'C203', 'C204', 'C205', 'C206', 'C207', 'C208',
                'R101', 'R102', 'R103', 'R104', 'R105', 'R106', 'R107', 'R108', 'R109', 'R110']

    num_runs = 20

    excel_file_name1 = 'HV_Values消融.xlsx'
    excel_file_name2 = 'IGD_Values消融.xlsx'

    # 定义表头
    hv_header = ['数据集'] + [f'HV({i})' for i in range(1, num_runs + 1)]
    igd_header = ['数据集'] + [f'IGD({i})' for i in range(1, num_runs + 1)]

    # 初始化 Excel 文件，确保表头正确
    def init_excel(file_path, header):
        if not os.path.exists(file_path):
            pd.DataFrame(columns=header).to_excel(file_path, index=False)
            print(f"创建 {file_path} 并写入表头")
        else:
            existing_df = pd.read_excel(file_path)
            if list(existing_df.columns) != header:
                pd.DataFrame(columns=header).to_excel(file_path, index=False)
                print(f"修复 {file_path} 表头")

    init_excel(excel_file_name1, hv_header)
    init_excel(excel_file_name2, igd_header)
    # 每份数据运行的次数
    for user_input in datasets:
        hv_list = []
        IGD_list = []
        for run in range(1, num_runs + 1):
            print(f"\n处理数据: {user_input}, 第 {run}/{num_runs} 次运行")

            # 构建处理后数据文件的文件名和路径
            filename = f"{user_input}_processed.txt"
            file_path = os.path.join("processed_data", filename)


            # 检查文件是否存在
            if os.path.exists(file_path):
                # 读取文件获取相关信息
                n, Q, nodes = read_txt_file(file_path)
                print("n", n)
                print("Q", Q)

                # 构建 k_meas_result 目录下的文件路径
                input_dir = os.path.join('k_meas_result', f"{user_input}.txt")


                # 处理所有文件并获取结果
                group_customers_list_all_files = process_all_files(input_dir, nodes)
                # print("group_customers_list_all_files", group_customers_list_all_files)


                times = calculate_travel_times(nodes)  # 每两个节点之间的距离矩阵，也是用时矩阵
                # print("times", times)



                m = 20

                pop = [PopIndividual() for _ in range(m)]

                # print("drl_list", drl_list)
                for i in range(0, m):
                    # result_list = [multi_point_swap(sublist.copy(), nodes) for sublist in original_list]
                    # print("result_list", result_list)
                    # print("drl_list[i]", drl_list[i])
                    routes = route_selection1(nodes, Q, times)
                    # print("routes", routes)
                    pop[i].position = routes

                print("pop", pop)
                start_time = time.time()
                last_generation_hv, last_generation_IGD = combined_search2(pop, times, run, Q, group_customers_list_all_files, start_time, user_input)

                hv_list.append(last_generation_hv)
                IGD_list.append(last_generation_IGD)


                computation_time = time.time() - start_time
                # total_time = time.time() - total_computation_time
                print("computation_time", computation_time)
                # print("total_time", total_time)
            else:
                print(f"Archivo {filename} no encontrado.")

                # 写入 HV 数据到 Excel
        try:
            # 构造新数据行，字典形式保证列对齐
            new_hv_data = {
                '数据集': user_input
            }
            for i in range(1, num_runs + 1):
                new_hv_data[f'HV({i})'] = hv_list[i - 1]

            # 读取已有数据
            hv_df = pd.read_excel(excel_file_name1)
            # 追加新行
            hv_df = pd.concat([hv_df, pd.DataFrame([new_hv_data])], ignore_index=True)
            # 写入，保留表头
            hv_df.to_excel(excel_file_name1, index=False)
            print(f'成功写入 {user_input} 的 HV 值到 {excel_file_name1}')
        except Exception as e:
            print(f'写入 {user_input} 的 HV 值失败: {str(e)}')

        # 写入 IGD 数据到 Excel
        try:
            new_igd_data = {
                '数据集': user_input
            }
            for i in range(1, num_runs + 1):
                new_igd_data[f'IGD({i})'] = IGD_list[i - 1]

            igd_df = pd.read_excel(excel_file_name2)
            igd_df = pd.concat([igd_df, pd.DataFrame([new_igd_data])], ignore_index=True)
            igd_df.to_excel(excel_file_name2, index=False)
            print(f'成功写入 {user_input} 的 IGD 值到 {excel_file_name2}')
        except Exception as e:
            print(f'写入 {user_input} 的 IGD 值失败: {str(e)}')

vrptw_solver()
