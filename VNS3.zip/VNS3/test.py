import re

input_str = "[[Customer <0>, Customer <25003>, Customer <23002>, Customer <23001>, Customer <3002>, Customer <15002>, Customer <4002>, Customer <29004>, Customer <27004>, Customer <44002>, Customer <0>], [Customer <0>, Customer <39004>, Customer <7003>, Customer <30004>, Customer <12001>, Customer <36004>, Customer <27003>, Customer <44001>, Customer <25001>, Customer <0>], [Customer <0>, Customer <19004>, Customer <50005>, Customer <49005>, Customer <11004>, Customer <35004>, Customer <36006>, Customer <18004>, Customer <16002>, Customer <0>], [Customer <0>, Customer <25004>, Customer <37004>, Customer <11003>, Customer <35005>, Customer <26004>, Customer <3001>, Customer <40002>, Customer <23003>, Customer <2003>, Customer <41004>, Customer <15003>, Customer <0>], [Customer <0>, Customer <7002>, Customer <13003>, Customer <37002>, Customer <26003>, Customer <45004>, Customer <8002>, Customer <10004>, Customer <40003>, Customer <6002>, Customer <0>], [Customer <0>, Customer <30001>, Customer <21002>, Customer <34001>, Customer <2002>, Customer <35002>, Customer <22002>, Customer <14003>, Customer <0>], [Customer <0>, Customer <22003>, Customer <9007>, Customer <47003>, Customer <49004>, Customer <14004>, Customer <46002>, Customer <12003>, Customer <0>], [Customer <0>, Customer <9004>, Customer <9003>, Customer <28004>, Customer <36002>, Customer <12002>, Customer <39001>, Customer <31001>, Customer <45003>, Customer <34004>, Customer <41001>, Customer <0>], [Customer <0>, Customer <17003>, Customer <48001>, Customer <22004>, Customer <41003>, Customer <1004>, Customer <49002>, Customer <9006>, Customer <28006>, Customer <40004>, Customer <0>], [Customer <0>, Customer <13002>, Customer <49001>, Customer <46001>, Customer <19001>, Customer <44003>, Customer <28005>, Customer <28008>, Customer <45001>, Customer <37003>, Customer <2004>, Customer <0>], [Customer <0>, Customer <47002>, Customer <34003>, Customer <49003>, Customer <28002>, Customer <11002>, Customer <39002>, Customer <30002>, Customer <9002>, Customer <0>], [Customer <0>, Customer <6001>, Customer <18002>, Customer <48002>, Customer <50003>, Customer <36003>, Customer <35003>, Customer <37001>, Customer <38003>, Customer <4003>, Customer <0>], [Customer <0>, Customer <42001>, Customer <4001>, Customer <6003>, Customer <3003>, Customer <33004>, Customer <33003>, Customer <34002>, Customer <44004>, Customer <0>], [Customer <0>, Customer <43003>, Customer <26002>, Customer <1002>, Customer <28003>, Customer <25002>, Customer <19002>, Customer <38002>, Customer <10002>, Customer <29002>, Customer <0>], [Customer <0>, Customer <20004>, Customer <28007>, Customer <9005>, Customer <36005>, Customer <6004>, Customer <50004>, Customer <21004>, Customer <12004>, Customer <0>], [Customer <0>, Customer <50001>, Customer <9008>, Customer <21001>, Customer <38001>, Customer <22001>, Customer <29003>, Customer <28001>, Customer <8001>, Customer <0>], [Customer <0>, Customer <33001>, Customer <36001>, Customer <50002>, Customer <40001>, Customer <10003>, Customer <35001>, Customer <14002>, Customer <39003>, Customer <0>], [Customer <0>, Customer <5004>, Customer <32001>, Customer <17004>, Customer <4004>, Customer <31003>, Customer <1003>, Customer <27001>, Customer <18003>, Customer <48003>, Customer <38004>, Customer <0>], [Customer <0>, Customer <43001>, Customer <7001>, Customer <16001>, Customer <31002>, Customer <15001>, Customer <47001>, Customer <10001>, Customer <2001>, Customer <1001>, Customer <0>], [Customer <0>, Customer <33002>, Customer <19003>, Customer <24001>, Customer <21003>, Customer <0>], [Customer <0>, Customer <29001>, Customer <20001>, Customer <46003>, Customer <32002>, Customer <38005>, Customer <42002>, Customer <3004>, Customer <0>], [Customer <0>, Customer <27002>, Customer <14001>, Customer <30003>, Customer <18001>, Customer <41002>, Customer <9001>, Customer <11001>, Customer <26001>, Customer <0>], [Customer <0>, Customer <42003>, Customer <5001>, Customer <13004>, Customer <20002>, Customer <43002>, Customer <17002>, Customer <0>], [Customer <0>, Customer <13001>, Customer <17001>, Customer <24002>, Customer <0>], [Customer <0>, Customer <45002>, Customer <0>], [Customer <0>, Customer <5002>, Customer <43005>, Customer <0>], [Customer <0>, Customer <5003>, Customer <0>], [Customer <0>, Customer <20003>, Customer <43004>, Customer <0>]]"

# routes PopIndividual(position=[[Customer <0>, Customer <13004>, Customer <13002>, Customer <17002>, Customer <18002>, Customer <19002>, Customer <19001>, Customer <16002>, Customer <14003>, Customer <12001>, Customer <12002>, Customer <0>], [Customer <0>, Customer <20001>, Customer <20002>, Customer <43002>, Customer <43003>, Customer <42002>, Customer <42003>, Customer <41001>, Customer <40001>, Customer <47002>, Customer <0>], [Customer <0>, Customer <32001>, Customer <32002>, Customer <33001>, Customer <33002>, Customer <31001>, Customer <35003>, Customer <35001>, Customer <37001>, Customer <0>], [Customer <0>, Customer <24001>, Customer <25001>, Customer <25002>, Customer <5001>, Customer <3003>, Customer <7003>, Customer <7002>, Customer <8002>, Customer <0>], [Customer <0>, Customer <35002>, Customer <37003>, Customer <37002>, Customer <38003>, Customer <38002>, Customer <38005>, Customer <39002>, Customer <39003>, Customer <36003>, Customer <0>], [Customer <0>, Customer <40002>, Customer <44001>, Customer <46003>, Customer <46001>, Customer <45001>, Customer <48002>, Customer <50003>, Customer <0>], [Customer <0>, Customer <30001>, Customer <30004>, Customer <30002>, Customer <22002>, Customer <0>], [Customer <0>, Customer <36001>, Customer <36004>, Customer <34001>, Customer <34003>, Customer <34004>, Customer <29001>, Customer <0>], [Customer <0>, Customer <10003>, Customer <10002>, Customer <11002>, Customer <45003>, Customer <44003>, Customer <50002>, Customer <49003>, Customer <49001>, Customer <21002>, Customer <23003>, Customer <26003>, Customer <0>], [Customer <0>, Customer <29004>, Customer <29002>, Customer <28008>, Customer <28003>, Customer <28002>, Customer <28005>, Customer <26002>, Customer <1002>, Customer <2002>, Customer <0>], [Customer <0>, Customer <9002>, Customer <6002>, Customer <4003>, Customer <0>], [Customer <0>, Customer <18003>, Customer <17004>, Customer <15003>, Customer <14004>, Customer <12003>, Customer <2003>, Customer <1003>, Customer <0>], [Customer <0>, Customer <33003>, Customer <33004>, Customer <35004>, Customer <35005>, Customer <37004>, Customer <38004>, Customer <39001>, Customer <36002>, Customer <34002>, Customer <0>], [Customer <0>, Customer <5004>, Customer <3001>, Customer <43004>, Customer <42001>, Customer <41004>, Customer <40003>, Customer <44004>, Customer <46002>, Customer <50005>, Customer <0>], [Customer <0>, Customer <11003>, Customer <10004>, Customer <9007>, Customer <9004>, Customer <6003>, Customer <4001>, Customer <4004>, Customer <0>], [Customer <0>, Customer <25004>, Customer <27001>, Customer <20003>, Customer <45004>, Customer <48003>, Customer <49004>, Customer <47003>, Customer <22003>, Customer <0>], [Customer <0>, Customer <17003>, Customer <18004>, Customer <15002>, Customer <11004>, Customer <4002>, Customer <1004>, Customer <6004>, Customer <0>], [Customer <0>, Customer <5002>, Customer <3002>, Customer <36005>, Customer <36006>, Customer <28007>, Customer <28006>, Customer <23001>, Customer <0>], [Customer <0>, Customer <43005>, Customer <40004>, Customer <41003>, Customer <45002>, Customer <44002>, Customer <48001>, Customer <50004>, Customer <49002>, Customer <0>], [Customer <0>, Customer <9005>, Customer <9006>, Customer <23002>, Customer <22004>, Customer <21004>, Customer <0>], [Customer <0>, Customer <13001>, Customer <17001>, Customer <18001>, Customer <29003>, Customer <28001>, Customer <26001>, Customer <0>], [Customer <0>, Customer <9001>, Customer <9008>, Customer <2001>, Customer <1001>, Customer <8001>, Customer <11001>, Customer <0>], [Customer <0>, Customer <43001>, Customer <41002>, Customer <7001>, Customer <10001>, Customer <27002>, Customer <22001>, Customer <0>]]), PopIndividual(cost=None)




pattern = r'Customer <\d+>'
matches = re.findall(pattern, input_str)

# 给元素加上引号并构建嵌套列表
data = []
sub_list = []
for match in matches:
    sub_list.append(f'"{match}"')
    if match == "Customer <0>":
        data.append(sub_list)
        sub_list = []

# 统计除去 "Customer <0>" 的总个数
count = 0.
for sub_list in data:
    for item in sub_list:
        if item != '"Customer <0>"':
            count = count + 1

print("除去 \"Customer <0>\" 的总个数为:", count)



#
# # 将子列表转换为元组以便使用集合操作
# set1 = set(tuple(item) for item in costs1)
# set2 = set(tuple(item) for item in costs2)
#
# # 找出仅在 costs1 中存在的元素
# only_in_costs1 = [list(item) for item in set1 - set2]
# # 找出仅在 costs2 中存在的元素
# only_in_costs2 = [list(item) for item in set2 - set1]
#
# print("仅在 costs1 中的子列表:", only_in_costs1)
# print("仅在 costs2 中的子列表:", only_in_costs2)

# indices = [i for i, val in enumerate(F[0])]
# 从 pop 中选取相应的元素
# ndices = F[0]
# print("indices", indices)
# F1 = [pop[i] for i in indices]

# def convert_to_str(nested_list):
#     """递归转换嵌套列表中的数字为字符串"""
#     converted = []
#     for item in nested_list:
#         if isinstance(item, list):
#             converted.append(convert_to_str(item))  # 递归处理子列表
#         else:
#             converted.append(str(item))  # 转换为字符串
#     print("converted", converted)
#     return converted
#
#
#
# A = [[0, 21001, 0, 47001, 49002, 0, 22001, 0, 23003, 23002, 0, 10001, 10002, 4002, 1001, 2001, 2003, 0, 20001, 26002, 26001, 28004, 28002, 28007, 28001, 28008, 0, 5004, 4004, 6001, 9001, 9002, 11001, 11004, 0, 24002, 27002, 29004, 29003, 29001, 30004, 30001, 30003, 0, 7001, 7002, 8001, 3002, 3003, 0, 43005, 43001, 43002, 42002, 45004, 45002, 50001, 50002, 48003, 48001, 46002, 0, 25001, 0, 40004, 40001, 44004, 44002, 42001, 0, 31003, 35005, 35002, 35001, 33001, 33004, 32001, 32002, 34002, 34004, 34003, 36003, 36002, 36006, 39003, 39002, 39001, 39004, 38004, 38001, 38002, 37002, 37001, 0, 13001, 13003, 17001, 18004, 18001, 19001, 19004, 14001, 12001, 14002, 16001, 0], [0, 21002, 0, 22002, 0, 47002, 49003, 0, 26004, 26003, 28003, 0, 10003, 11002, 9003, 9006, 1002, 2004, 2002, 0, 4003, 6002, 0, 20002, 0, 41003, 40002, 44003, 50004, 48002, 45003, 46001, 0, 41004, 43003, 0, 25003, 0, 5003, 3004, 0, 34001, 36001, 38003, 38005, 37003, 35004, 35003, 31002, 33002, 33003, 0, 13002, 15002, 14003, 12002, 19002, 18002, 17003, 0], [0, 21003, 0, 22003, 0, 47003, 49001, 49004, 0, 1003, 4001, 0, 22004, 0, 20003, 23001, 0, 5002, 6003, 9004, 9005, 11003, 0, 5001, 3001, 0, 28006, 28005, 27003, 0, 41002, 40003, 44001, 50003, 45001, 0, 43004, 0, 25002, 0, 12003, 15001, 19003, 18003, 17002, 0, 36005, 36004, 0], [0, 21004, 0, 49005, 46003, 0, 0, 0, 10004, 1004, 0, 25004, 29002, 30002, 27001, 27004, 24001, 0, 37004, 31001, 0, 41001, 42003, 0, 20004, 0, 8002, 6004, 9008, 9007, 7003, 0, 13004, 17004, 15003, 12004, 14004, 16002, 0]]
#
# convert_to_str(A)
#
#
# # 合并后的总路线（假设已存储在 merged_route 变量中）
# # 此处需替换为你的实际数据，示例如下：


import matplotlib.pyplot as plt
import pandas as pd
import os

# # 配置
# FILE_PATH = 'C:\\Users\\cym\\Desktop\\VNS\\C101_hv_values.csv'  # 替换为实际的 CSV 文件路径
# FIGURE_TITLE = 'Convergence Curve of HV Value'  # 图表标题
# X_LABEL = 'Iteration'  # X 轴标签
# Y_LABEL = 'HV Value'   # Y 轴标签
# MARKER = 'o'           # 数据点标记样式
# LINE_STYLE = '-'       # 线条样式
# COLOR = 'b'            # 线条和标记颜色
# GRID = True            # 是否显示网格


# def plot_convergence_curve(file_path, figure_title, x_label, y_label, marker, line_style, color, grid):
#     """
#     绘制收敛曲线的函数
#     :param file_path: CSV 文件路径
#     :param figure_title: 图表标题
#     :param x_label: X 轴标签
#     :param y_label: Y 轴标签
#     :param marker: 数据点标记样式
#     :param line_style: 线条样式
#     :param color: 线条和标记颜色
#     :param grid: 是否显示网格
#     """
#     # 检查文件是否存在
#     if not os.path.exists(file_path):
#         print(f"错误：文件 {file_path} 不存在！")
#         return
#
#     try:
#         # 读取 CSV 文件数据
#         data = pd.read_csv(file_path)
#
#         # 检查必要的列是否存在
#         if 'Iteration' not in data.columns or 'HV Value' not in data.columns:
#             print("错误：CSV 文件缺少 'Iteration' 或 'HV Value' 列！")
#             return
#
#         # 提取迭代次数和 HV 值
#         iterations = data['Iteration']
#         hv_values = data['HV Value']
#
#         # 绘制收敛曲线
#         plt.figure(figsize=(10, 6))  # 设置图表大小
#         plt.plot(iterations, hv_values, marker=marker, linestyle=line_style, color=color, label='HV Value')
#
#         # 添加标题和标签
#         plt.title(figure_title, fontsize=14, fontweight='bold')
#         plt.xlabel(x_label, fontsize=12)
#         plt.ylabel(y_label, fontsize=12)
#
#         # 添加图例
#         plt.legend(loc='upper left', fontsize=10)
#
#         # 显示网格
#         plt.grid(grid)
#
#         # 优化坐标轴刻度
#         plt.tick_params(axis='both', which='major', labelsize=10)
#
#         # 保存图表（可选）
#         # plt.savefig('convergence_curve.png', dpi=300, bbox_inches='tight')
#
#         # 显示图表
#         plt.show()
#
#     except Exception as e:
#         print(f"绘制收敛曲线时发生错误：{str(e)}")
#
#
# if __name__ == "__main__":
#     plot_convergence_curve(
#         file_path=FILE_PATH,
#         figure_title=FIGURE_TITLE,
#         x_label=X_LABEL,
#         y_label=Y_LABEL,
#         marker=MARKER,
#         line_style=LINE_STYLE,
#         color=COLOR,
#         grid=GRID
#     )