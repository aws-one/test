pareto_front = [[1, 3, 2], [2, 3, 5], [2, 1, 4]]
solution_paths = [[0, 2, 3, 1, 0], [0, 2, 1, 3, 0], [0, 1, 3, 2, 0]]
current_length = len(pareto_front)

# 为原始pareto_front中的每个解创建一个索引映射
original_index_mapping = {tuple(sol): idx for idx, sol in enumerate(pareto_front)}

# 保存原始的pareto_front
original_pareto_front = pareto_front.copy()

# 更新pareto_front
pareto_front = [[1, 3, 2], [2, 1, 4]]

# 找到新的pareto_front中每个解在原始列表中的索引
new_indices = [original_index_mapping[tuple(solution)] for solution in pareto_front if tuple(solution) in original_index_mapping]

solution_paths = [solution_paths[i] for i in new_indices]

print("pareto_front", pareto_front)
print("solution_paths", solution_paths)